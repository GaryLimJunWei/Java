package application;

import controller.LoginController;

public class UserLoginAuthentication 
{
	public static void main(String[] args) // this method is just to call another class	
	{
		LoginController refLoginController = new LoginController(); // creating object just to call another class
	
		refLoginController.userLoginController();
		// just to call this method from another class
	}
}
