package controller;

import java.util.Scanner;

import pojo.User;
import service.LoginService;
import service.LoginServiceImpl;

public class LoginController 
{
	
	// loose coupling through reference of the interface
	LoginService refLoginService; // LoginService is an interface
	User refUser; // User is a POJO class
	
	// direct dependecies 
	
	public void userLoginController()
	{
		userInput();
	}
	
	void userInput()
	{
		Scanner s = new Scanner(System.in);
		
		//step 1 : ask user ID and password
		System.out.println("Enter User ID : ");
		int userID = s.nextInt();
		
		System.out.println("Enter Password : ");
		String password = s.next();
		System.out.println(refUser);
		// Step 2 : Create object of User Class
		refUser = new User();
		
		//Step 3 : set values to setter method of User Class
		refUser.setUserID(userID);
		refUser.setUserPassword(password);
		
		// step 4 : create object of LoginserviceImpl class and refer to its interface
		refLoginService = new LoginServiceImpl(); // we have to create object 
		// creating object to call the method from the parent class
		
		// step 5 : call checkStatus method and pass the reference of User class
		refLoginService.checkStatus(refUser);
		
		
		
	}
}
