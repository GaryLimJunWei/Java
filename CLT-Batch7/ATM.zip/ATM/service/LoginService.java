
package service;

import pojo.User;

public interface LoginService
{
	void checkStatus(User refUsers);
	//methods in interface have no body
	//methods in interface have the body on the other class with the same name
	
}
