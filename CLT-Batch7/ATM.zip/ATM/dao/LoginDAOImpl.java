package dao;

import pojo.User;

public class LoginDAOImpl implements LoginDAO 
{
	
	boolean status;
	
	

	@Override
	public boolean loginValidate(User asd) 
	{
		if(asd.getUserID()==1234 && asd.getUserPassword().equals("test"))
				{
					status = true;
				}
				else
				{
					status = false;
				}
				
				return status;

	}

}
