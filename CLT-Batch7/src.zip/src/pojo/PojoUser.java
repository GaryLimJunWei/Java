package pojo;

import java.util.Scanner;

import bankService.MessagePrintServices;
import bankService.MessagePrintServicesImpl;
import bankService.UserChoiceService;
import bankService.UserChoiceServiceImpl;
import controller.Controller;

public class PojoUser
{
	private double bankAmount;
	private static String email,password,color;
	Scanner s = new Scanner(System.in); //Passing the Scanner Object to lessen the heap memory
	MessagePrintServices refMsg = new MessagePrintServicesImpl(); //up casting
	UserChoiceService refChoice = new UserChoiceServiceImpl(); //up casting
	Controller refControl = new Controller();
	
	
	public Controller getRefControl() {
		return refControl;
	}
	
	public Scanner getS() {
		return s;
	}
	
	public MessagePrintServices getRefMsg() {
		return refMsg;
	}
	
	public UserChoiceService getRefChoice() {
		return refChoice;
	}
	
	
	
	
	

	public static String getEmail() {
		return email;
	}

	public static String getPassword() {
		return password;
	}

	public static String getColor() {
		return color;
	}

	public static void setEmail(String email) {
		PojoUser.email = email;
	}

	public static void setPassword(String password) {
		PojoUser.password = password;
	}

	public static void setColor(String color) {
		PojoUser.color = color;
	}

	public void depositAmount(double amt)
	{
		bankAmount += amt; 
	}
	
	public void withdrawAmount(double amt)
	{
		bankAmount -= amt;
	}
	
	private String DefaultEmail = "xyz@gmail.com";
	
	
	public void setBankAmount(double bankAmount) {
		this.bankAmount = bankAmount;
	}
	
	public void setDefaultEmail(String defaultEmail) {
		DefaultEmail = defaultEmail;
	}
	
	public double getBankAmount() {
		return bankAmount;
	}
	
	
	public String getDefaultEmail() {
		return DefaultEmail;
	}


	
	
	
	
	

}
