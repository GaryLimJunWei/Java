package bankDAO;
import java.util.Scanner;

import bankService.MessagePrintServices;
import controller.Controller;
import pojo.PojoUser;

public class UserChoiceDAOImpl implements UserChoiceDAO 
{
	String email,password,color;
	//When user choice is number 1 this is the method that do the registeration
	public void choiceOne() //Registeration Page
	{
		System.out.println("Enter email address : ");
		email = s.next();
		PojoUser.setEmail(email);
		if(userRef.getDefaultEmail().equalsIgnoreCase(email))
		{
			do
			{
				System.out.println("email already exists!!");
				System.out.println("Enter email address again : ");
				email = s.next();
				PojoUser.setEmail(email);
			}
		     while((userRef.getDefaultEmail().equalsIgnoreCase(email)));
		}
		else
		{
			PojoUser.setEmail(email);
		}
		

		
		System.out.println("Enter Password : ");
		password = s.next();
		System.out.println("Re-type Password : ");
		String tempPassword = s.next();
		if(!(tempPassword.equals(password)))
		{
			do
			{
				System.out.println("Password doesn't match!!");
				System.out.println("Re-type Password : ");
				tempPassword = s.next();
				PojoUser.setPassword(tempPassword);
			}
			while(!(tempPassword.equals(password)));
			
		}
		
		else
		{
			PojoUser.setPassword(tempPassword);
		}
		
		System.out.println("What is your favourite color ? ");
		color = s.next();
		System.out.println(color+" is your security key, in case if you forget your password. ");
		PojoUser.setColor(color);
		
		System.out.println(" ");
		System.out.println("Registration Successful!!");
		System.out.println("\n");
		refControl.tryCatch(refControl);
		
	}

// ===============================================================================================================
// ===============================================================================================================
// ===============================================================================================================
	
	//Choice Two is for Login verification 
	public void choiceTwo(PojoUser userRef, Controller refControl, MessagePrintServices refMsg, UserChoiceDAO choiceSvc,
			Scanner s)
	{
		int value=0;
		System.out.println("Enter User ID : ");
		email = s.next();
	
		if(!(email.equalsIgnoreCase(PojoUser.getEmail())))
		{
			System.out.println("No such email found, please register!");
			refControl.tryCatch(refControl);
		}

			System.out.println("Enter Password : ");
			String pass = s.next();
			if(!(pass.equals(PojoUser.getPassword())))
			{	
					do
					{
						System.out.println("Wrong Password input!");
						System.out.println("Enter Password again : ");
						pass = s.next();
						
						value++;
					}while(!(pass.equals(PojoUser.getPassword())) || value==3);

				
						
			}
			System.out.println("Login Successful!");
			refMsg.message2(userRef, refMsg, s, choiceSvc,refControl);
		}
		
	
	// ===============================================================================================================
	// ===============================================================================================================
	// ===============================================================================================================
	// Choice Three is when user forget password
	public void choiceThree(PojoUser userRef,Controller refControl,Scanner s) //Forget Password
	{

			System.out.println("Enter Your ID : ");
			String tempID = s.next();
			if(!(PojoUser.getEmail().equalsIgnoreCase(tempID)))
			{
				System.out.println("No such ID found!");
				refControl.tryCatch(refControl);
			}
			
			System.out.println("Enter your security key :");
			String tempSecurity = s.next();
			if(!(PojoUser.getColor().equalsIgnoreCase(tempSecurity)))
			{
				System.out.println("Wrong Security Password, please try again !");
				refControl.tryCatch(refControl);
			}

			
			System.out.println("Enter new password : ");
			String tempNewPass = s.next();
			System.out.println("Retype Password :");
			String tempNewPass2 = s.next();
			
			if(!(tempNewPass.equals(tempNewPass2)))
			{
				System.out.println("Password doesn't match!");
				refControl.tryCatch(refControl);
			}
			
			System.out.println("What is your favourite colour? ");
			color = s.next();
			System.out.println(color+" is your security key, in case if you forget your password. ");
			PojoUser.setColor(color);
			
			System.out.println("\n Your password has been reset successfully.");
			refControl.tryCatch(refControl);
		}
		
		
	// ===============================================================================================================
	// ===============================================================================================================
	// ===============================================================================================================
	// Choice Four is to exit the program
	public void choiceFour() //Logout(Exit)
	{
		System.out.println("Logout Successfully!!! \n");
		System.exit(0);
	}
	
	// ===============================================================================================================
	// ===============================================================================================================
	// ===============================================================================================================
	
	//This is the option where user can choose after login
	
	
	public void loginoption(int choice,PojoUser userRef, MessagePrintServices refMsg, Scanner s, UserChoiceDAO choiceSvc,Controller refControl)
	{
			double temp;
			switch(choice)
			{
			case 1 : System.out.println("Available Balance  : $"+userRef.getBankAmount());
	                 refMsg.wishToContinue(userRef,refMsg,s,choiceSvc,refControl);
	                 break;
			case 2 : System.out.println("Enter Amount : ");
					 temp = s.nextDouble();
					 if(temp<=0.0)
					{
						 for (int i = 0; i<=2; i++) 
						 {
							System.out.println("Amount can't be negative!!");	
							System.out.println("Enter Amount : ");
							temp = s.nextDouble();
						 }
						 refMsg.message2(userRef,refMsg,s,choiceSvc,refControl);
					 }
						System.out.println("$"+temp+" dollars deposited successfully!!");
						userRef.depositAmount(temp);
						refMsg.wishToContinue(userRef,refMsg,s,choiceSvc,refControl);
						break;
						
			case 3 : System.out.println("Enter Amount : ");
					 temp = s.nextDouble();
						if(temp<=0)
						{
							for (int i = 0; i<=2; i++) 
							 {
								System.out.println("Amount can't be negative!!");
								System.out.println("Enter Amount : ");
								temp = s.nextDouble();
							 }
							
						}
						else if(temp>userRef.getBankAmount())
						{
							System.out.println("Sorry!! insufficient balance\n");
							refMsg.wishToContinue(userRef,refMsg,s,choiceSvc,refControl);
							
						}
						else
						{
							System.out.println("Transcation Successful!!");
							userRef.withdrawAmount(temp);
							refMsg.wishToContinue(userRef,refMsg,s,choiceSvc,refControl);
							break;
						}
						
	}
	}






}







	
	
			
		

