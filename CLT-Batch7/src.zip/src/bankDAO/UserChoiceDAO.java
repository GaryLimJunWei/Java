package bankDAO;

import java.util.Scanner;

import bankService.MessagePrintServices;
import bankService.MessagePrintServicesImpl;
import controller.Controller;
import pojo.PojoUser;

public interface UserChoiceDAO 
{
	public void choiceOne();
	public void choiceTwo();
	public void choiceThree();
	public void choiceFour();
	public void loginoption();
}
