package controller;

import java.util.Scanner;

import bankService.MessagePrintServices;
import bankService.MessagePrintServicesImpl;
import bankService.UserChoiceService;
import bankService.UserChoiceServiceImpl;
import pojo.PojoUser;


public class Controller 
{
	Scanner s = new Scanner(System.in);
	public void tryCatch(PojoUser refUser)
	{
		int choice = 0;
		while(true) //true means continue forever till there's a break
		{
			try 
			{
				refUser.getRefMsg().message2();
				choice = s.nextInt();
				option(choice,refUser);
//				Passing the object reference so we do not need to create multiple objects											
			} 
			catch (Exception e) 
			{
				System.out.println("Invalid input, try again");
				s.next();
				 //reset the input
				continue; //when it catches the exception,break is automatic
				//continue let the loop continues
			}
			break; //This break will stop the while loop
		}
	}
	
	
	

}


public void option(int choice,PojoUser refUser)
{

		try 
		{ //This is where the user choice will determine what is next logic
			switch(choice)
			{
			case 1 : refUser
					break;
			case 2 : refChoiceSvc.choiceTwo(userRef,refControl,refMsg,refChoiceSvc, s);
					break;
			case 3 : refChoiceSvc.choiceThree(userRef,refControl,s);
					break;
			case 4 : refChoiceSvc.choiceFour();
			        break;
			}
		}
			catch (Exception e) 
		{
			System.out.println("wrong input!");
			refControl.tryCatch(refControl);
		}
