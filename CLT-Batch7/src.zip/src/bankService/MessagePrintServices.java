package bankService;

import java.util.Scanner;

import bankDAO.UserChoiceDAO;
import bankDAO.UserChoiceDAOImpl;
import controller.Controller;
import pojo.PojoUser;

public interface MessagePrintServices 
{
	public void message();
	public void wishToContinue();
	public void message2();
}
