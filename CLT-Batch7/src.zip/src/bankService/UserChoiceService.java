package bankService;
import java.util.Scanner;

import controller.Controller;
import pojo.PojoUser;

public interface UserChoiceService 
{
	public void option();
	
}
