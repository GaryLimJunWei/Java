package bankService;

import java.util.Scanner;

import bankDAO.UserChoiceDAO;
import bankDAO.UserChoiceDAOImpl;
import controller.Controller;
import pojo.PojoUser;


public class MessagePrintServicesImpl implements MessagePrintServices 
{
	int choice;
	public void message()

	{
				System.out.println("User Home Page : ");
				System.out.println("1. Register");
				System.out.println("2. Login");
				System.out.println("3. Forget Password");
				System.out.println("4. Logout(exit) ");
				System.out.println(" ");
				System.out.println("Enter Your Choice : ");
				
	}
	@Override
	public void message2() 
	{
		while(true)
		{
			try 
			{
				System.out.println("Type 1 : Check Available Bank Balance ");
				System.out.println("Type 2 : Deposit Amount ");
				System.out.println("Type 3 : Withdraw Amount ");
				choice = s.nextInt();
				choiceSvc.loginoption();
				
			} 
			catch (Exception e) 
			{
				System.out.println("Wrong input, try again");
				s.next();
				continue;
				
			}
			
		}
		
		
	}
	
	

	
		public void wishToContinue()
	{
		String ans;
		try 
		{
			System.out.println("Wish to Continue? (y/n) : ");
			ans = s.next();
			if(ans.equalsIgnoreCase("y"))
			{
				message2();	
				
			}
			else if(ans.equalsIgnoreCase("n"))
			{
				System.out.println("Thanks for Banking with Us !!!\n");
				refControl.tryCatch();
			}
			else
			{
				System.out.println("Wrong input! Try again");
				refMsg.wishToContinue();
			}
		
				
				
		} 
		catch (Exception e) 
		{
			System.out.println("Wrong input!!");
			refMsg.message2();
		}
		
	}
		






		
		

}
