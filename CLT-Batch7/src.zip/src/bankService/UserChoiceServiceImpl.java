package bankService;

import java.util.Scanner;

import bankDAO.UserChoiceDAOImpl;
import controller.Controller;
import pojo.PojoUser;


public class UserChoiceServiceImpl implements UserChoiceService 
{

    public void option()
	{

			try 
			{ //This is where the user choice will determine what is next logic
				switch(choice)
				{
				case 1 : refChoiceSvc.choiceOne(userRef,refControl,s);
						break;
				case 2 : refChoiceSvc.choiceTwo(userRef,refControl,refMsg,refChoiceSvc, s);
						break;
				case 3 : refChoiceSvc.choiceThree(userRef,refControl,s);
						break;
				case 4 : refChoiceSvc.choiceFour();
				        break;
				}
			}
				catch (Exception e) 
			{
				System.out.println("wrong input!");
				refControl.tryCatch(refControl);
			}
			

		
		
		
			
			
		} 

}
