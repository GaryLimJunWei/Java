package atmApplication.application;

import pojo.PojoUser;

public class Main 
{

	public static void main(String[] args) 
	{
		
		PojoUser refUser = new PojoUser();
		refUser.getRefControl().tryCatch(refUser);
	}

}
