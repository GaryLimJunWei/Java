package bankDAO;
import java.util.Scanner;

import atmapp1.MessagePrintService1;
import bankServices.MessagePrintDAO;
import bankServices.MessagePrintDAOImpl;
import controller.Controller;
import pojo.PojoUser;

public class ChoiceServiceImpl implements ChoiceService 
{
	String email,password,color;
	//When user choice is number 1 this is the method that do the registeration
	public void choiceOne(PojoUser userRef,Controller refControl,Scanner s) //Registeration Page
	{
		System.out.println("Enter email address : ");
		email = s.next();
		userRef.setEmail(email);
		if(userRef.getDefaultEmail().equalsIgnoreCase(email))
		{
			
			do
			{
				System.out.println("email already exists!!");
				System.out.println("Enter email address again : ");
				email = s.next();
				userRef.setEmail(email);
			}
		     while((userRef.getDefaultEmail().equals(email)));
		}
		
		else
		{
			userRef.setEmail(email);
		}
		

		
		System.out.println("Enter Password : ");
		password = s.next();
		System.out.println("Re-type Password : ");
		String tempPassword = s.next();
		if(!(tempPassword.equals(password)))
		{
			do
			{
				System.out.println("Password doesn't match!!");
				System.out.println("Re-type Password : ");
				tempPassword = s.next();
				userRef.setPassword(tempPassword);
			}
			while(!(tempPassword.equals(password)));
			
		}
		
		else
		{
			userRef.setPassword(tempPassword);
		}
		
		System.out.println("What is your favourite color ? ");
		color = s.next();
		System.out.println(color+" is your security key, in case if you forget your password. ");
		userRef.setColor(color);
		
		System.out.println(" ");
		System.out.println("Registration Successful!!");
		System.out.println("\n");
		refControl.tryCatch(null);
	}

// ===============================================================================================================
// ===============================================================================================================
// ===============================================================================================================
	
	//Choice Two is for Login verification 
	public void choiceTwo(PojoUser userRef, Controller refControl, MessagePrintDAO refMsg, ChoiceService choiceSvc,
			Scanner s)
	{
		System.out.println("Enter User ID : ");
		email = s.next();
		if(!(email.equals(userRef.getEmail())))
		{
			System.out.println("No such email found, please register!");
			refControl.tryCatch(refControl);
		}
		else
		{
			System.out.println("Enter Password : ");
			String pass = s.next();
			if(!(pass.equals(userRef.getPassword())))

					{
						do
						{
							System.out.println("Wrong Password input!");
							System.out.println("Enter Password again : ");
							pass = s.next();
							
						}while(!(pass.equals(userRef.getPassword())));
						
					}
			
			System.out.println("Login Successful!");
		}
		
	}
	
	// ===============================================================================================================
	// ===============================================================================================================
	// ===============================================================================================================
	// Choice Three is when user forget password
	public void choiceThree(PojoUser userRef,Controller refControl,Scanner s) //Forget Password
	{

			System.out.println("Enter Your ID : ");
			String tempID = s.next();
			userRef.setEmail(tempID);
			if(!(userRef.getEmail().equalsIgnoreCase(tempID)))
			{
				System.out.println("No such ID found!");
				refControl.tryCatch(null);
			}
			
			System.out.println("Enter your security key :");
			String tempSecurity = s.next();
			userRef.setColor(tempSecurity);
			if(!(userRef.getColor().equalsIgnoreCase(tempSecurity)))
			{
				System.out.println("Wrong Security Password, please try again !");
				refControl.tryCatch(null);
			}
			
			System.out.println("Enter new password : ");
			String tempNewPass = s.next();
			System.out.println("Retype Password :");
			String tempNewPass2 = s.next();
			
			if(!(tempNewPass.equals(tempNewPass2)))
			{
				System.out.println("Password doesn't match!");
				refControl.tryCatch(null);
			}
			
			System.out.println("What is your favourite colour? ");
			color = s.next();
			System.out.println(color+" is your security key, in case if you forget your password. ");
			userRef.setColor(color);
			
			System.out.println("\n Your password has been reset successfully.");
			refControl.tryCatch(null);
		}
		
		
	// ===============================================================================================================
	// ===============================================================================================================
	// ===============================================================================================================
	// Choice Four is to exit the program
	public void choiceFour() //Logout(Exit)
	{
		System.out.println("Logout Successfully!!! \n");
		System.exit(0);
	}
	
	// ===============================================================================================================
	// ===============================================================================================================
	// ===============================================================================================================
	
	//This is the option where user can choose after login
	public void loginoption(PojoUser userRef,MessagePrintDAOImpl refMsg,Scanner s)
	{
			double temp;
			switch(userRef.getChoice())
			{
			case 1 : System.out.println("Available Balance  : $"+userRef.getBankAmount());
	                 refMsg.wishToContinue(null);
	                 break;
			case 2 : System.out.println("Enter Amount : ");
					 temp = s.nextDouble();
					 if(temp<=0.0)
						{
							System.out.println("Amount can't be negative!!");	
							refMsg.message2(null);
						}
						System.out.println("$"+temp+" dollars deposited successfully!!");
						userRef.depositAmount(temp);
						refMsg.wishToContinue(null);
						break;
						
			case 3 : System.out.println("Enter Amount : ");
					 temp = s.nextDouble();
			
						if(temp<=0)
						{
							System.out.println("Amount can't be negative!!");
							System.out.println("Enter Amount : ");
							temp = s.nextDouble();
						}
						else if(temp>userRef.getBankAmount())
						{
							System.out.println("Sorry!! insufficient balance");
							refMsg.wishToContinue(null);
						}
							userRef.withdrawAmount(temp);
							System.out.println("Transcation Successful!!");
							refMsg.wishToContinue(null);
							break;
			}
	}




	
	
			
		
}
