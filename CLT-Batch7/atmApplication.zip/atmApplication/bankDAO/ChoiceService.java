package bankDAO;

import java.util.Scanner;

import bankServices.MessagePrintDAO;
import bankServices.MessagePrintDAOImpl;
import controller.Controller;
import pojo.PojoUser;

public interface ChoiceService 
{
	public void choiceOne(PojoUser userRef,Controller refControl,Scanner s);
	public void choiceTwo(PojoUser userRef,Controller refControl,MessagePrintDAO refMsg,ChoiceService choiceSvc,Scanner s);
	public void choiceThree(PojoUser userRef,Controller refControl,Scanner s);
	public void choiceFour();
	public void loginoption(PojoUser userRef,MessagePrintDAOImpl refMsg,Scanner s);
}
