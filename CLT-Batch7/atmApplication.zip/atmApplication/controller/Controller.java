package controller;

import java.util.Scanner;

import bankServices.MessagePrintDAO;
import bankServices.MessagePrintDAOImpl;
import bankServices.UserChoiceDAO;
import bankServices.UserChoiceImpl;
import pojo.PojoUser;


public class Controller 
{
	public void tryCatch(Controller refControl)
	{
		int choice = 0;
		PojoUser userRef = new PojoUser();
		Scanner s = new Scanner(System.in); //Passing the Scanner Object to lessen the heap memory
		MessagePrintDAO refMsg = new MessagePrintDAOImpl(); //up casting
		UserChoiceDAO refChoice = new UserChoiceImpl(); //up casting
		while(true) //true means continue forever till there's a break
		{
			try 
			{
				refMsg.message();
				choice = s.nextInt();
				userRef.setChoice(choice);
				refChoice.option(userRef,s,refMsg,refControl); 
//				Passing the object reference so we do not need to create multiple objects											
			} 
			catch (Exception e) 
			{
				System.out.println("Invalid input, try again");
				s.next(); //reset the input
				continue; //when it catches the exception,break is automatic
				//continue let the loop continues
			}
			break; //This break will stop the while loop
		}
	}

}
