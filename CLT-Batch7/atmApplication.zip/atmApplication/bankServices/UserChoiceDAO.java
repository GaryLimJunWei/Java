package bankServices;
import java.util.Scanner;

import controller.Controller;
import pojo.PojoUser;

public interface UserChoiceDAO 
{
	public void option(PojoUser userRef,Scanner s,MessagePrintDAO refMsg,Controller refControl);
	
}
