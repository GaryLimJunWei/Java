package bankServices;

import bankDAO.ChoiceServiceImpl;

public interface MessagePrintDAO 
{
	public void message();
	public void message2(ChoiceServiceImpl choiceSvc);
	public void wishToContinue(ChoiceServiceImpl choiceSvc);
	public void wrongInput();
}
