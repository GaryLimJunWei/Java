package bankServices;

import java.util.Scanner;

import bankDAO.ChoiceServiceImpl;
import controller.Controller;
import pojo.PojoUser;


public class MessagePrintDAOImpl implements MessagePrintDAO 
{
	Scanner s = new Scanner(System.in);
	int choice;
	PojoUser refUser = new PojoUser();
	Controller refControl = new Controller();
	public void message()

	{
				System.out.println("User Home Page : ");
				System.out.println("1. Register");
				System.out.println("2. Login");
				System.out.println("3. Forget Password");
				System.out.println("4. Logout(exit) ");
				System.out.println(" ");
				System.out.println("Enter Your Choice : ");
				
	}
	
		public void message2(ChoiceServiceImpl choiceSvc)
	{
		
		while(true)
		{
			try 
			{
				System.out.println("Type 1 : Check Available Bank Balance ");
				System.out.println("Type 2 : Deposit Amount ");
				System.out.println("Type 3 : Withdraw Amount ");
				choice = s.nextInt();
				refUser.setChoice(choice);
				choiceSvc.loginoption(null, null, s);
				
			} 
			catch (Exception e) 
			{
				System.out.println("Wrong input, try again");
				s.next();
				continue;
				
			}
			
		}
		
	
		
		
	}
	
		public void wishToContinue(ChoiceServiceImpl choiceSvc)
	{
		String ans;
		System.out.println("Wish to Continue? (y/n) : ");
		ans = s.next();
		if(ans.equalsIgnoreCase("y"))
		{
			message2(choiceSvc);	
		}
		else if(ans.equalsIgnoreCase("n"))
		{
			System.out.println("Thanks for Banking with Us !!!\n");
			refControl.tryCatch(null);
		}
		else
		{
			wrongInput();
		}
	}
		
		public void wrongInput()
		{
			System.out.println("Logout Successfully!!! \n");
			System.exit(0);
		}
		
		

}
