package bankServices;

import java.util.Scanner;
import bankDAO.ChoiceServiceImpl;
import controller.Controller;
import pojo.PojoUser;


public class UserChoiceImpl implements UserChoiceDAO 
{
	double temp=0.0;
	ChoiceServiceImpl refChoiceSvc = new ChoiceServiceImpl();
    public void option(PojoUser userRef,Scanner s,MessagePrintDAO refMsg,Controller refControl)
	{
		while(true)
		{
			try 
			{ //This is where the user choice will determine what is next logic
				switch(userRef.getChoice())
				{
				case 1 : refChoiceSvc.choiceOne(userRef,refControl,s);
						break;
				case 2 : refChoiceSvc.choiceTwo(userRef,refControl,refMsg,refChoiceSvc, s);
						break;
				case 3 : refChoiceSvc.choiceThree(userRef,refControl,s);
						break;
				case 4 : refChoiceSvc.choiceFour();
				        break;
				}
			}
				catch (Exception e) 
			{
				System.out.println("wrong input!1");
				refControl.tryCatch(refControl);
			}
			
			break;
		}
		
		
		
			
			
		} 

}
